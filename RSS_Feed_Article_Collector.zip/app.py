from flask import Flask, render_template
from feedparser import parse
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import spacy
from datetime import datetime
from celery import Celery

app = Flask(__name__)

# Database setup
DATABASE_URI = 'sqlite:///articles.db'
engine = create_engine(DATABASE_URI)
Base = declarative_base()
Session = sessionmaker(bind=engine)
session = Session()

# Define Article model
class Article(Base):
    __tablename__ = 'articles'
    id = Column(Integer, primary_key=True)
    title = Column(String)
    content = Column(String)
    published = Column(DateTime)
    url = Column(String)
    category = Column(String)

Base.metadata.create_all(engine)

# Load spaCy model
nlp = spacy.load('en_core_web_sm')

# Initialize Celery
celery = Celery(app.name, broker='redis://localhost:6379/0')

# Categories
categories = {
    'terrorism': ['terrorism', 'protest', 'political unrest', 'riot'],
    'positive': ['positive', 'uplifting'],
    'natural_disasters': ['earthquake', 'flood', 'hurricane'],
}

# Function to categorize articles
def categorize_article(content):
    doc = nlp(content)
    for category, keywords in categories.items():
        for keyword in keywords:
            if keyword in content.lower():
                return category
    return 'Others'

# Fetch RSS feeds
RSS_FEEDS = [
    'http://rss.cnn.com/rss/cnn_topstories.rss',
    'http://qz.com/feed',
    'http://feeds.foxnews.com/foxnews/politics',
    'http://feeds.reuters.com/reuters/businessNews',
    'http://feeds.feedburner.com/NewshourWorld',
    'https://feeds.bbci.co.uk/news/world/asia/india/rss.xml'
]

# Celery task to process articles
@celery.task
def process_articles():
    for feed in RSS_FEEDS:
        feed_data = parse(feed)
        for entry in feed_data.entries:
            title = entry.title
            content = entry.summary if hasattr(entry, 'summary') else ''
            published = datetime(*entry.published_parsed[:6])
            url = entry.link
            category = categorize_article(content)

            # Store in database if not duplicate
            if not session.query(Article).filter_by(url=url).first():
                article = Article(title=title, content=content, published=published, url=url, category=category)
                session.add(article)
                session.commit()

# Route to display articles
@app.route('/')
def index():
    articles = session.query(Article).all()
    return render_template('index.html', articles=articles)

if __name__ == '__main__':
    app.run(debug=True)
