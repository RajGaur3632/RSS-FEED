# RSS Feed Article Collector

## Project Overview

This project collects news articles from various RSS feeds, categorizes them into predefined categories, and displays them on a web page. The application is built using Flask for the web framework, SQLAlchemy for database interactions, Celery for task management, and spaCy for natural language processing.

## Features

- Fetches articles from multiple RSS feeds.
- Categorizes articles into predefined categories:
  - Terrorism / protest / political unrest / riot
  - Positive / Uplifting
  - Natural Disasters
  - Others
- Stores articles in a SQLite database.
- Displays articles in a user-friendly web interface.

## Requirements

- Python 3.x
- Flask
- SQLAlchemy
- Feedparser
- Celery
- Redis (for task queue)
- spaCy
- pyngrok (for exposing local server)

## Installation

1. Clone the repository or download the files.
2. Install the required packages:

   ```bash
   pip install -r requirements.txt
   ```

3. Download the spaCy language model:

   ```bash
   python -m spacy download en_core_web_sm
   ```

4. Set up a Redis server (if not already running):

   - Follow the instructions on the Redis website to install and start Redis.

5. Update your `app.py` file with your ngrok authentication token.

6. Run the application:

   ```bash
   python app.py
   ```

7. Expose your Flask app using ngrok:

   ```bash
   ngrok http 5000
   ```

8. Access your app at the provided ngrok URL.

## File Structure

```
/project-root
│
├── app.py               # Main application file
├── requirements.txt     # Required Python packages
├── README.md            # Project documentation
│
├── templates/           # HTML templates
│   └── index.html       # Main page template
│
└── static/              # Static files (CSS, images, etc.)
    └── styles.css       # CSS styles for the app
```

## Usage

- Visit the home page to view the articles fetched from the RSS feeds.
- Each article shows its title, publication date, category, and content.

## Logging and Error Handling

The application logs important events and errors during the feed parsing and storage processes. Ensure that logging is properly configured to capture relevant information.

## Acknowledgements

This project utilizes various libraries and frameworks:

- [Flask](https://flask.palletsprojects.com/)
- [SQLAlchemy](https://www.sqlalchemy.org/)
- [Feedparser](https://pythonhosted.org/feedparser/)
- [Celery](https://docs.celeryproject.org/en/stable/)
- [spaCy](https://spacy.io/)
- [ngrok](https://ngrok.com/)
- [Redis](https://redis.io/)

For further information on each of these libraries, please refer to their respective documentation.
